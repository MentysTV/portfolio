⚡ CYBER PC MONITOR v1.1.0
=========================================
Jak aplikaci spustit:
1. Klikněte dvakrát na "SPUSTIT_CYBER_PC_MONITOR.bat" (doporučeno - automaticky odblokuje Windows ochranu).
2. Nebo spusťte přímo "Cyber_PC_Monitor.exe". Pokud se objeví modré okno Windows SmartScreen, klikněte na "Další informace" -> "Přesto spustit".
3. Aplikace se otevře v prohlížeči na adrese http://localhost:8765

Novinky ve verzi v1.1.0:
- Celkový stav počítače (🟢 Výborný / 🟡 Zvýšená zátěž / 🔴 Kritické vytížení)
- Průvodce "Co co znamená?" s vysvětlením procesoru, RAM, disků i sítě
- Přehledné hardwarové specifikace
- Automatická kontrola a upozornění na nové aktualizace přímo v liště!
