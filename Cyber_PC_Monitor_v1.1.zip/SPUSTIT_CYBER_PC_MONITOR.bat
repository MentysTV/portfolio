@echo off
title CYBER PC MONITOR // SPUŠTĚNÍ
chcp 65001 >nul
cd /d "%~dp0"

:: Odblokování Windows SmartScreen zóny (ochrana před modrou obrazovkou SmartScreen u stažených souborů)
powershell -NoProfile -Command "Unblock-File -Path '%~dp0Cyber_PC_Monitor.exe' 2>$null; Get-ChildItem -Path '%~dp0_internal' -Recurse | Unblock-File 2>$null" >nul 2>&1

:: Spuštění monitoru
start "" "%~dp0Cyber_PC_Monitor.exe"
exit
